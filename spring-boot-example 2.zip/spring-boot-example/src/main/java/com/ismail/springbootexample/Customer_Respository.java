package com.ismail.springbootexample;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Customer_Respository extends JpaRepository<Customer, String> {
}
