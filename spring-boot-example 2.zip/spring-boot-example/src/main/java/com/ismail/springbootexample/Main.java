package com.ismail.springbootexample;
 //port org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.swing.*;
import java.util.List;
import java.util.Optional;

@SpringBootApplication
@RestController
///@RequestMapping("api/v1/customer")
public class Main {
    //Injection to the customer repository
    private final Customer_Respository customerRespository;
    private final Student_Repository studentRepository;

    public Main(Customer_Respository customerRespository, Student_Repository studentRepository) {
        this.customerRespository = customerRespository;
        this.studentRepository = studentRepository;
    }

    public static  void main( String [] args) {
        SpringApplication.run(Main.class,args);










    }
    @GetMapping("api/v1/students")
    public List<Student_info> getStudentinfo(){
        return studentRepository.findAll();

    }


    // Posting values of the students into repository
    record NewStudentRequest(
            String std_name,
            String class_name ,
            String marks
    ){

    }
   //Post
    @PostMapping("api/v1/students")
    public void addstudent(@RequestBody NewStudentRequest request){
        Student_info student_info= new Student_info();
        student_info.setStd_name(request.std_name);
        student_info.setClass_name(request.class_name);
        student_info.setMarks(request.marks);
        studentRepository.save(student_info);
    }


    ///Customers Section API
 @GetMapping("api/v1/customers")
   public List<Customer> getCustomer(){
        return  customerRespository.findAll();
   }

    record NewCustomerRequest (
            String name ,
            String email ,
            Integer age
    ){

    }
    @PostMapping("api/v1/customers")
    public void addcustomer(@RequestBody NewCustomerRequest request) {
        Customer customer  = new Customer();
        customer.setName(request.name);
        customer.setEmail(request.email);
        customer.setAge(request.age);
        customerRespository.save(customer);


  }

    @DeleteMapping("api/v1/customers/{customer_id}")
    public void deleteCustomer(@PathVariable("customer_id") String customerId) {
        System.out.println("Deleting customer with ID: " + customerId);
        ///String customer_id = String.valueOf(customerId);
        customerRespository.deleteById(customerId);
    }
    @PutMapping("api/v1/customers/{customer_id}")
    public void updateCustomer(@PathVariable("customer_id") String customerId ,
                               @RequestBody NewCustomerRequest request){

        Optional<Customer> optionalCustomer = customerRespository.findById(customerId);

        if(optionalCustomer.isPresent()) {
            //Update the existing customer's properties
           /// Customer customer = new Customer();
            Customer customer = optionalCustomer.get();
            customer.setName(request.name);
            customer.setAge(request.age);
            customer.setEmail(request.email);
            customerRespository.save(customer);
        }
        else {
            System.out.println("Customer not found with ID: " + customerId);
        }

    }


}


