package com.ismail.springbootexample;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Student_Repository extends JpaRepository<Student_info, Integer>  {

    //CRUD Applications
}
