package com.ismail.springbootexample;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "Student_info")
public class Student_info {
  @Id
  @SequenceGenerator(
          name = "student_id_sequence",
          sequenceName ="student_id_sequence",
          allocationSize = 1

  )
  @GeneratedValue (
          strategy = GenerationType.SEQUENCE,
          generator = "student_id_sequence"
  )



    private Integer std_id;
    private String std_name ;
    private String class_name ;
    private String marks;
    // Default constructor
    public Student_info() {
    }
    public Student_info(Integer std_id, String std_name, String class_name, String marks) {
        this.std_id = std_id;
        this.std_name = std_name;
        this.class_name = class_name;
        this.marks = marks;
    }

    public Integer getStd_id() {
        return std_id;
    }

    public void setStd_id(Integer std_id) {
        this.std_id = std_id;
    }

    public String getStd_name() {
        return std_name;
    }

    public void setStd_name(String std_name) {
        this.std_name = std_name;
    }

    public String getClass_name() {
        return class_name;
    }

    public void setClass_name(String class_name) {
        this.class_name = class_name;
    }

    public String getMarks() {
        return marks;
    }

    public void setMarks(String marks) {
        this.marks = marks;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student_info that = (Student_info) o;
        return Objects.equals(std_id, that.std_id) && Objects.equals(std_name, that.std_name) && Objects.equals(class_name, that.class_name) && Objects.equals(marks, that.marks);
    }

    @Override
    public int hashCode() {
        return Objects.hash(std_id, std_name, class_name, marks);
    }




}
